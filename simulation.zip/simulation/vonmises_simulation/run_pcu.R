N = as.double(commandArgs(trailingOnly = TRUE)[1])
arclength = as.double(commandArgs(trailingOnly = TRUE)[2])
alpha = as.double(commandArgs(trailingOnly = TRUE)[3])


library(rstan)
library(circular)

stan_model_pc <- "models/von_mises_pc_uniform_stan.stan"
source("functions/get_lambda_vm_pc_uniform.R")
source("functions/init_fn_vonmises_stan.R")
source("functions/simulate_fit_averaging_vm_pc.R")
source("functions/get_true_kappa_from_arclength.R")
source("setting/conformable_setting.R")

kappa <- get_true_kappa_from_arclength(arclength)

lambda <- get_lambda_vm_pc_uniform(U = U_kappa, alpha = alpha)

res <- simulate_fit_vonmises_pc(m = m, N = N, mu_true = mu_true,
                                  kappa_true = kappa,
                                  lambda = lambda,
                                stan_model_vm_pc = stan_model_pc,
                                  init_fn = init_fn_vonmises_stan,
                                  random_seed = 520)

print(res)

# Ensure the output folder exists
output_folder <- "results_pc_uniform/"
if (!dir.exists(output_folder)) {
  dir.create(output_folder)
}

# Combine the values into a data frame correctly (for averaged results)
results_df <- data.frame(
  lower_95 = res$lower_95,
  upper_95 = res$upper_95,
  mean = res$posterior_mean,
  median = res$posterior_median,
  se_mean = res$se_mean,
  sd = res$sd
)

# Format kappa to two decimal places
kappa_formatted <- sprintf("%.2f", kappa)

# Use the formatted kappa in the file names
fnm_combined <- paste0(output_folder, "pcu-", N, "-", kappa_formatted, "-", alpha, ".csv")
write.csv(results_df, file = fnm_combined, row.names = FALSE)

fnm_done <- paste0(output_folder, "done-pcu-", N, "-", kappa_formatted, "-", alpha)
cat("done-pcu", file = fnm_done)
