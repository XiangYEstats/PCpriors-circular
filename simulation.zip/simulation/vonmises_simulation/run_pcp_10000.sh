#!/bin/bash -l
#SBATCH -p batch
#SBATCH -J "simulation_jobs_N10000"
#SBATCH --time=96:00:00
#SBATCH -o Err_Out/%A_%a.out
#SBATCH -e Err_Out/%A_%a.err
#SBATCH --nodes=8
#SBATCH --ntasks-per-node=1
#SBATCH --mem=150GB
#SBATCH --array=1-56

# Load required modules (if needed)
source ~/lmodules.sh

# Ensure output directory exists
mkdir -p Err_Out

# Define fixed N value and varying arclength and alpha values
N=10000
# Calculate pi-related values using bc
arclength_values=(
  $(echo "scale=10; 4*a(1)/30" | bc -l)     # pi/30
  $(echo "scale=10; 4*a(1)/8" | bc -l)       # pi/8
  $(echo "scale=10; 4*a(1)/4" | bc -l)       # pi/4
  $(echo "scale=10; 4*a(1)/2" | bc -l)       # pi/2
  $(echo "scale=10; 3*4*a(1)/4" | bc -l)     # 3pi/4
  $(echo "scale=10; 4*a(1)" | bc -l)         # pi
  $(echo "scale=10; 3*4*a(1)/2" | bc -l)     # 3pi/2
  $(echo "scale=10; 59*4*a(1)/30" | bc -l) # 59pi/30
)

alpha_values=(0.01 0.1 0.3 0.5 0.7 0.9 0.99)

# Compute indices for arclength and alpha based on SLURM_ARRAY_TASK_ID
# Compute indices for arclength and alpha based on SLURM_ARRAY_TASK_ID
index=$((SLURM_ARRAY_TASK_ID-1))
arclength_idx=$((index / ${#alpha_values[@]}))
alpha_idx=$((index % ${#alpha_values[@]}))

arclength=${arclength_values[$arclength_idx]}
alpha=${alpha_values[$alpha_idx]}

# Run the R script with the current combination of N, arclength, alpha
arclength_formatted=$(printf "%.2f" "$arclength")
Rscript run_pcp.R $N $arclength $alpha > PCP-$N-$arclength_formatted-$alpha.out 2>&1

