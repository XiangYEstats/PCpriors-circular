N = as.double(commandArgs(trailingOnly = TRUE)[1])
arclength = as.double(commandArgs(trailingOnly = TRUE)[2])

library(rstan)
library(circular)

stan_model <- "models/von_mises_dowe1996_h2_prior_stan.stan"
source("functions/init_fn_vonmises_stan.R")
source("functions/simulate_fit_averaging_vm_dowe.R")
source("functions/get_true_kappa_from_arclength.R")
source("setting/conformable_setting.R")

kappa <- get_true_kappa_from_arclength(arclength)

res <- simulate_fit_vonmises_dowe(m = m, N = N, mu_true = mu_true,
                                  kappa_true = kappa,
                                stan_model = stan_model,
                                  init_fn = init_fn_vonmises_stan,
                                  random_seed = 520)

print(res)

# Ensure the output folder exists
output_folder <- "results_h2/"
if (!dir.exists(output_folder)) {
  dir.create(output_folder)
}

# Combine the values into a data frame correctly (for averaged results)
results_df <- data.frame(
  lower_95 = res$lower_95,
  upper_95 = res$upper_95,
  mean = res$posterior_mean,
  median = res$posterior_median,
  se_mean = res$se_mean,
  sd = res$sd
)

# Format kappa to two decimal places
kappa_formatted <- sprintf("%.2f", kappa)

# Use the formatted kappa in the file names
fnm_combined <- paste0(output_folder, "h2-", N, "-", kappa_formatted, ".csv")
write.csv(results_df, file = fnm_combined, row.names = FALSE)

fnm_done <- paste0(output_folder, "done-h2-", N, "-", kappa_formatted)
cat("done-h2", file = fnm_done)
