get_true_kappa_from_arclength <- function(arclength){
  return(2*pi/arclength - 1)
}