#!/bin/bash -l
#SBATCH -p batch
#SBATCH -J "simulation_jobs_N100"
#SBATCH --time=12:00:00
#SBATCH -o Err_Out/%A_%a.out
#SBATCH -e Err_Out/%A_%a.err
#SBATCH --nodes=8
#SBATCH --ntasks-per-node=1
#SBATCH --mem=150GB
#SBATCH --array=1-8

# Load required modules (if needed)
source ~/lmodules.sh

# Ensure output directory exists
mkdir -p Err_Out

# Define fixed N value and varying arclength and alpha values
N=100
# Calculate pi-related values using bc
arclength_values=(
  $(echo "scale=10; 4*a(1)/30" | bc -l)     # pi/30
  $(echo "scale=10; 4*a(1)/8" | bc -l)       # pi/8
  $(echo "scale=10; 4*a(1)/4" | bc -l)       # pi/4
  $(echo "scale=10; 4*a(1)/2" | bc -l)       # pi/2
  $(echo "scale=10; 3*4*a(1)/4" | bc -l)     # 3pi/4
  $(echo "scale=10; 4*a(1)" | bc -l)         # pi
  $(echo "scale=10; 3*4*a(1)/2" | bc -l)     # 3pi/2
  $(echo "scale=10; 59*4*a(1)/30" | bc -l) # 59pi/30
)


# Compute indices for arclength and alpha based on SLURM_ARRAY_TASK_ID
index=$((SLURM_ARRAY_TASK_ID-1))
arclength=${arclength_values[$index]}

# Run the R script with the current combination of N, arclength, alpha
arclength_formatted=$(printf "%.2f" "$arclength")
Rscript run_h3.R $N $arclength > h3-$N-$arclength_formatted.out 2>&1
