#!/bin/bash -l
#SBATCH -p batch
#SBATCH -J "simulation_jobs_N100"
#SBATCH --time=12:00:00
#SBATCH -o Err_Out/%A_%a.out
#SBATCH -e Err_Out/%A_%a.err
#SBATCH --nodes=8
#SBATCH --ntasks-per-node=1
#SBATCH --mem=150GB
#SBATCH --array=1-112

# Load required modules (if needed)
source ~/lmodules.sh

# Ensure output directory exists
mkdir -p Err_Out
mkdir -p $R_LIBS

# Define fixed N value and varying ell, a, and b values
N=100
ell_values=(0 0.01 0.1 0.2 0.3 0.4 0.49)
a_values=(0.5 1 2 5)
b_values=(0.5 1 2 5)

# Total number of a and b combinations
ab_combinations=$(( ${#a_values[@]} * ${#b_values[@]} ))

# Set the index from the SLURM array task ID (zero-based)
index=$((SLURM_ARRAY_TASK_ID - 1))

# Compute indices for ell (previously "rho"), and the combined index for a and b
ell_idx=$((index / ab_combinations))
ab_idx=$((index % ab_combinations))

# Compute indices for a_values and b_values
a_idx=$((ab_idx / ${#b_values[@]}))
b_idx=$((ab_idx % ${#b_values[@]}))

# Extract the specific values
ell=${ell_values[$ell_idx]}
a_ell=${a_values[$a_idx]}
b_ell=${b_values[$b_idx]}

# Run the R script with the current combination of N, rho, a_rho, and b_rho
Rscript run_beta.R $N $ell $a_ell $b_ell > BETA-$N-$ell-$a_ell-$b_ell.out 2>&1

