library(rstan)
library(circular)
library(ggplot2)
library(dplyr)
library(viridis)

stan_model_pc_pm <- "settings/vm_pc_pm_stan_model.stan"
stan_model_pc_uni <- "settings/vm_pc_uni_stan_model.stan"
stan_model_exp <- "settings/vm_exp_stan_model.stan"
stan_model_h2 <- "settings/vm_h2_stan_model.stan"
stan_model_h3 <- "settings/vm_h3_stan_model.stan"
source("settings/init_fn_vonmises_stan.R")
source("settings/get_lambda_vm_pc_pm.R")
source("settings/get_lambda_vm_pc_uni.R")

data(wind)
xs <- wind
set.seed(1314) # Set seed for reproducibility
xs <- xs[sample(length(xs), 100)] # Randomly sample 100 observations
length(xs)
summary(xs)
plot.circular(xs, stack = TRUE)

compute_results <- function(xs, U_sequence) {
  results <- data.frame()
  
  for (U in U_sequence) {
    # Compute alpha and lambda
    quarter_pi_count <- sum(xs < U/2 | xs > (2 * pi - U/2))
    alpha <- 1 - quarter_pi_count / length(xs)
    lambda_pm <- get_lambda_vm_pc_pm(U = U, alpha = alpha)
    lambda_uni <- get_lambda_vm_pc_uni(U = U, alpha = alpha)
    
    # Prepare data for Stan
    data_pm <- list(
      N = length(xs),
      x = as.numeric(xs),
      lambda = lambda_pm
    )
    
    data_uni <- list(
      N = length(xs),
      x = as.numeric(xs),
      lambda = lambda_uni
    )
    
    # Fit models
    set.seed(520)
    fit_pm <- stan(
      file = stan_model_pc_pm,
      data = data_pm,
      iter = 5000,
      warmup = 1500,
      chains = 4,
      init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
    )
    
    set.seed(520)
    fit_uni <- stan(
      file = stan_model_pc_uni,
      data = data_uni,
      iter = 5000,
      warmup = 1500,
      chains = 4,
      init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
    )
    
    # Extract results for pm
    fit_pm_summary <- summary(fit_pm)$summary
    mu_pm_mean <- fit_pm_summary["mu", "mean"]
    mu_pm_ci <- c(fit_pm_summary["mu", "2.5%"], fit_pm_summary["mu", "97.5%"])
    kappa_pm_mean <- fit_pm_summary["kappa", "mean"]
    kappa_pm_ci <- c(fit_pm_summary["kappa", "2.5%"], fit_pm_summary["kappa", "97.5%"])
    var_pm <- 1 - besselI(kappa_pm_mean, 1) / besselI(kappa_pm_mean, 0)
    
    # Extract results for uni
    fit_uni_summary <- summary(fit_uni)$summary
    mu_uni_mean <- fit_uni_summary["mu", "mean"]
    mu_uni_ci <- c(fit_uni_summary["mu", "2.5%"], fit_uni_summary["mu", "97.5%"])
    kappa_uni_mean <- fit_uni_summary["kappa", "mean"]
    kappa_uni_ci <- c(fit_uni_summary["kappa", "2.5%"], fit_uni_summary["kappa", "97.5%"])
    var_uni <- 1 - besselI(kappa_uni_mean, 1) / besselI(kappa_uni_mean, 0)
    
    # Combine results into a data frame
    results <- rbind(
      results,
      data.frame(
        U = U, alpha = alpha, type = "pm", lambda = lambda_pm,
        mu_mean = mu_pm_mean, mu_ci_lower = mu_pm_ci[1], mu_ci_upper = mu_pm_ci[2],
        kappa_mean = kappa_pm_mean, kappa_ci_lower = kappa_pm_ci[1], kappa_ci_upper = kappa_pm_ci[2],
        variance = var_pm
      ),
      data.frame(
        U = U, alpha = alpha, type = "uni", lambda = lambda_uni,
        mu_mean = mu_uni_mean, mu_ci_lower = mu_uni_ci[1], mu_ci_upper = mu_uni_ci[2],
        kappa_mean = kappa_uni_mean, kappa_ci_lower = kappa_uni_ci[1], kappa_ci_upper = kappa_uni_ci[2],
        variance = var_uni
      )
    )
  }
  
  return(results)
}

# Generate U sequence and compute results
U_sequence <- pi / 2^(0:4)
results_df <- compute_results(xs, U_sequence)

results_df <- results_df %>%
  mutate(lambda = round(lambda, 2))

# Function for running `exp` model
run_exp_models <- function(xs, lambda_values) {
  results <- data.frame()
  
  for (lambda in lambda_values) {
    data_exp <- list(
      N = length(xs),
      x = as.numeric(xs),
      lambda = lambda
    )
    
    set.seed(520)
    fit_exp <- stan(
      file = stan_model_exp,
      data = data_exp,
      iter = 5000,
      warmup = 1500,
      chains = 4,
      init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
    )
    
    fit_exp_summary <- summary(fit_exp)$summary
    mu_mean <- fit_exp_summary["mu", "mean"]
    mu_ci <- c(fit_exp_summary["mu", "2.5%"], fit_exp_summary["mu", "97.5%"])
    kappa_mean <- fit_exp_summary["kappa", "mean"]
    kappa_ci <- c(fit_exp_summary["kappa", "2.5%"], fit_exp_summary["kappa", "97.5%"])
    variance <- 1 - besselI(kappa_mean, 1) / besselI(kappa_mean, 0)
    
    results <- rbind(
      results,
      data.frame(
        type = "exp", lambda = lambda, mu_mean = mu_mean,
        mu_ci_lower = mu_ci[1], mu_ci_upper = mu_ci[2],
        kappa_mean = kappa_mean, kappa_ci_lower = kappa_ci[1],
        kappa_ci_upper = kappa_ci[2], variance = variance
      )
    )
  }
  
  return(results)
}

# Function for running `h2` and `h3` models
run_h_models <- function(xs, model_file, model_type) {
  data_h <- list(
    N = length(xs),
    x = as.numeric(xs)
  )
  
  set.seed(520)
  fit_h <- stan(
    file = model_file,
    data = data_h,
    iter = 5000,
    warmup = 1500,
    chains = 4,
    init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
  )
  
  fit_h_summary <- summary(fit_h)$summary
  mu_mean <- fit_h_summary["mu", "mean"]
  mu_ci <- c(fit_h_summary["mu", "2.5%"], fit_h_summary["mu", "97.5%"])
  kappa_mean <- fit_h_summary["kappa", "mean"]
  kappa_ci <- c(fit_h_summary["kappa", "2.5%"], fit_h_summary["kappa", "97.5%"])
  variance <- 1 - besselI(kappa_mean, 1) / besselI(kappa_mean, 0)
  
  results <- data.frame(
    type = model_type, mu_mean = mu_mean,
    mu_ci_lower = mu_ci[1], mu_ci_upper = mu_ci[2],
    kappa_mean = kappa_mean, kappa_ci_lower = kappa_ci[1],
    kappa_ci_upper = kappa_ci[2], variance = variance
  )
  
  return(results)
}

# Run `exp` models with lambda values
lambda_values <- c(0.1, 1, 2, 5, 10)
results_exp <- run_exp_models(xs, lambda_values)

# Run `h2` and `h3` models
results_h2 <- run_h_models(xs, stan_model_h2, "h2")
results_h3 <- run_h_models(xs, stan_model_h3, "h3")

results_combined <- bind_rows(
  results_df,  # Existing pm/uni results
  results_exp %>% mutate(type = "exp"),  # Add exp type
  results_h2 %>% mutate(type = "h2", lambda = NA),  # Add h2 type
  results_h3 %>% mutate(type = "h3", lambda = NA)   # Add h3 type
)

# Add variance bounds for all models
results_combined <- results_combined %>%
  mutate(
    variance_lower = 1 - besselI(kappa_ci_upper, 1) / besselI(kappa_ci_upper, 0),
    variance_upper = 1 - besselI(kappa_ci_lower, 1) / besselI(kappa_ci_lower, 0)
  )


# Set lambda values for h2 and h3
results_combined <- results_combined %>%
  mutate(
    lambda = ifelse(type == "h2", 0.08,
                    ifelse(type == "h3", 0.09, lambda)),
    lambda = as.factor(lambda)  # Convert lambda to a factor
  )

# Create a mapping for type labels
label_mapping <- c(
  "exp" = "EXP",
  "h2" = "h2",
  "h3" = "h3",
  "pm" = "PCP",
  "uni" = "PCU"
)

# Generate the plot with updated x-axis labels
plot <- ggplot(results_combined, aes(x = type, y = variance, color = lambda, group = interaction(type, lambda))) +
  geom_point(position = position_dodge(width = 0.8), size = 3) +  # Points with dodge for grouping
  geom_errorbar(
    aes(ymin = variance_lower, ymax = variance_upper),
    width = 0.3,
    position = position_dodge(width = 0.8),
    size = 1
  ) +
  geom_text(
    aes(label = ifelse(type == "h2", "h2 prior",
                       ifelse(type == "h3", "h3 prior", paste0("λ = ", lambda))),
        y = variance_upper),  # Labels for h2, h3, or lambda
    position = position_dodge(width = 0.8),
    vjust = -0.5,  # Offset slightly above the upper bound
    size = 4
  ) +
  geom_hline(yintercept = var.circular(xs), color = "black", linetype = "dashed", size = 1.2) +  # Horizontal reference line
  labs(
    x = "Prior Type",
    y = "Variance",
    title = "Variance with Credible Interval Error Bars by Prior Type"
  ) +
  scale_x_discrete(labels = label_mapping) +  # Use the label mapping
  theme_grey(base_size = 14) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_line(color = "grey90"),
    panel.grid.minor = element_line(color = "grey90"),
    legend.position = "none",  # Remove the legend
    axis.text.x = element_text(size = 12, face = "bold"),
    axis.text.y = element_text(size = 12)
  ) +
  scale_color_viridis_d(option = "viridis", begin = 0.2, end = 0.8)  # Use Viridis colors for lambda

# Print the plot
print(plot)

