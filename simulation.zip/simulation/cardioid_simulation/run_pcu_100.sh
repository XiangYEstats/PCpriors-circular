#!/bin/bash -l
#SBATCH -p batch
#SBATCH -J "simulation_jobs_N100"
#SBATCH --time=12:00:00
#SBATCH -o Err_Out/%A_%a.out
#SBATCH -e Err_Out/%A_%a.err
#SBATCH --nodes=8
#SBATCH --ntasks-per-node=1
#SBATCH --mem=150GB
#SBATCH --array=1-42

# Load required modules (if needed)
source ~/lmodules.sh

# Ensure output directory exists
mkdir -p Err_Out
mkdir -p $R_LIBS

# Define fixed N value and varying arclength and alpha values
N=100
# Calculate pi-related values using bc
ell_values=(0 0.01 0.1 0.2 0.3 0.4 0.49)

alpha_values=(0.01 0.1 0.2 0.3 0.4 0.5)

# Compute indices for arclength and alpha based on SLURM_ARRAY_TASK_ID
index=$((SLURM_ARRAY_TASK_ID-1))
ell_idx=$((index / ${#alpha_values[@]}))
alpha_idx=$((index % ${#alpha_values[@]}))

ell=${ell_values[$ell_idx]}
alpha=${alpha_values[$alpha_idx]}


# Run the R script with the current combination of N, ell, alpha
Rscript run_pcu.R $N $ell $alpha > PCU-$N-$ell-$alpha.out 2>&1
