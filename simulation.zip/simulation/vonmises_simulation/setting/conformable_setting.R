m <- 100  # Number of simulations
mu_true <- pi  # True mu value
U_kappa <- pi/2  # Compute U_rho for prior