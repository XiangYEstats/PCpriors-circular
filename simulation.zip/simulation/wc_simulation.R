# Load required libraries
library(ggplot2)
library(gridExtra)
library(dplyr)
library(cowplot)
library(viridis)

# 1. A new format_name function that uses basename() so only the filename is used
format_name <- function(filename) {
  fname <- basename(filename)  # Use only the filename, not the full path
  
  # PC pattern: pc-N-rho-alpha.csv
  if (grepl("^pc-", fname)) {
    match <- regmatches(fname, 
                        regexec("pc-(\\d+)-(\\d+\\.?\\d*)-(\\d+\\.?\\d*)\\.csv", fname))[[1]]
    # match[2] = N, match[3] = rho, match[4] = alpha
    new_name <- paste0("N", match[2], "_rho", match[3], "_alpha", match[4])
    
    # Beta pattern: beta-N-rho-a-b.csv
  } else if (grepl("^beta-", fname)) {
    match <- regmatches(fname, 
                        regexec("beta-(\\d+)-(\\d+\\.?\\d*)-(\\d+\\.?\\d*)-(\\d+\\.?\\d*)\\.csv", fname))[[1]]
    # match[2] = N, match[3] = rho, match[4] = a, match[5] = b
    new_name <- paste0("N", match[2], "_rho", match[3], "_a", match[4], "_b", match[5])
    
  } else {
    new_name <- fname  # Fallback if naming doesn't match
  }
  return(new_name)
}

# 2. Read in PC and Beta CSV files
pc_files <- list.files(
  path = "wrappedcauchy_simulation/results_pc", 
  pattern = "^pc-.*\\.csv$", 
  full.names = TRUE
)
pc_data <- lapply(pc_files, read.csv)
names(pc_data) <- sapply(pc_files, format_name)

beta_files <- list.files(
  path = "wrappedcauchy_simulation/results_beta", 
  pattern = "^beta-.*\\.csv$", 
  full.names = TRUE
)
beta_data <- lapply(beta_files, read.csv)
names(beta_data) <- sapply(beta_files, format_name)

# 3. Combine into a single data frame, tagging each row with prior_type and prior_setting

# For the PC files, extract 'alpha' from the id string (e.g. "N1000_rho0.80_alpha0.05")
pc_combined <- bind_rows(pc_data, .id = "id") %>%
  mutate(
    prior_type = "PC",
    alpha = as.numeric(sub(".*_alpha([0-9.]+)$", "\\1", id)),
    prior_setting = paste0("PC(", alpha, ")")
  )

# For the Beta files, extract 'a' and 'b' from the id string (e.g. "N1000_rho0.80_a1.2_b3.4")
beta_combined <- bind_rows(beta_data, .id = "id") %>%
  mutate(
    prior_type = "Beta",
    a = as.numeric(sub(".*_a([0-9.]+)_b([0-9.]+)$", "\\1", id)),
    b = as.numeric(sub(".*_a([0-9.]+)_b([0-9.]+)$", "\\2", id)),
    prior_setting = paste0("Beta(", a, ",", b, ")")
  )

# Combine both datasets and also extract N and rho
combined_df <- bind_rows(pc_combined, beta_combined) %>%
  mutate(
    N = as.numeric(sub("N(\\d+)_.*", "\\1", id)),
    rho = as.numeric(sub(".*_rho([0-9.]+)_.*", "\\1", id))
  )

# 4. Summarize if needed (assuming columns 'mean', 'lower_95', 'upper_95' exist)
combined_df <- combined_df %>%
  group_by(N, rho, prior_type, prior_setting) %>%
  summarise(
    mean = mean(mean, na.rm = TRUE),
    lower_95 = mean(lower_95, na.rm = TRUE),
    upper_95 = mean(upper_95, na.rm = TRUE),
    .groups = "drop"
  )


# -------------------------------
# Set up color palettes
# -------------------------------

# Get the unique prior settings for each group
pc_levels <- unique(combined_df$prior_setting[combined_df$prior_type == "PC"])
beta_levels <- unique(combined_df$prior_setting[combined_df$prior_type == "Beta"])

# Generate distinct color palettes using viridis for each group
pc_colors <- viridis(length(pc_levels), option = "viridis")
beta_colors <- viridis(length(beta_levels), option = "viridis")

# Combine the color palettes into one named vector
color_values <- c(
  setNames(pc_colors, pc_levels),
  setNames(beta_colors, beta_levels)
)

# -------------------------------
# Create the plot
# -------------------------------

plot <- ggplot(combined_df, 
               aes(x = prior_type, y = mean, color = prior_setting, group = prior_setting)) +
  geom_point(position = position_dodge(width = 0.8)) +
  geom_errorbar(aes(ymin = lower_95, ymax = upper_95), 
                width = 0.8, 
                position = position_dodge(width = 0.8), 
                size = 1.5) +
  # Facet by 'rho' (rows) and sample size 'N' (columns)
  facet_grid(rho ~ N, scales = "free_y", labeller = labeller(N = function(x) paste0("N=", x))) +
  labs(
    x = "Prior Class", 
    y = expression(rho~"(wrapped Cauchy concentration)"), 
    color = "Priors"
  ) +
  theme_grey(base_size = 14) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_line(color = "grey90"),
    panel.grid.minor = element_line(color = "grey90"),
    legend.position = "top",
    legend.text = element_text(size = 24),
    legend.title = element_text(size = 30, face = "bold"),
    axis.title.x = element_text(size = 32, face = "bold"),
    axis.title.y = element_text(size = 32, face = "bold"),
    axis.text.x  = element_text(size = 30),
    axis.text.y  = element_text(size = 30),
    strip.text.x = element_text(size = 30, face = "bold"),
    strip.text.y = element_text(size = 30, face = "bold")
  ) +
  scale_color_manual(values = color_values) +
  guides(color = guide_legend(title = "Priors", nrow = 2)) +
  # Add a horizontal dashed line for the true rho value in each facet
  geom_hline(data = combined_df %>% distinct(rho),
             aes(yintercept = rho),
             color = "black",
             linetype = 2,
             linewidth = 1.5)

# Display the plot
print(plot)

# Save the plot to a file (adjust the dimensions as needed)
ggsave("wc_simulation.png", plot = plot, width = 75, height = 73, units = "cm", dpi = 300, bg = "white")
