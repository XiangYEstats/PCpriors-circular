library(rstan)
library(circular)

stan_model_pc_pm <- "settings/vm_pc_pm_stan_model.stan"
stan_model_pc_uni <- "settings/vm_pc_uni_stan_model.stan"
stan_model_exp <- "settings/vm_exp_stan_model.stan"
stan_model_h2 <- "settings/vm_h2_stan_model.stan"
stan_model_h3 <- "settings/vm_h3_stan_model.stan"
source("settings/init_fn_vonmises_stan.R")
source("settings/get_lambda_vm_pc_pm.R")
source("settings/get_lambda_vm_pc_uni.R")

data(wind)
xs <- wind
#set.seed(1314) # Set seed for reproducibility
#xs <- xs[sample(length(xs), 100)] # Randomly sample 100 observations
length(xs)
summary(xs)
plot.circular(xs, stack = TRUE)

quarter_xs <- sum(xs < pi/4 | xs > 7*pi/4)
quarter_xs
alpha <- 1 - quarter_xs/length(xs)
alpha
U <- pi/2

lambda_pm <- get_lambda_vm_pc_pm(U = U, alpha = alpha)
lambda_uni<- get_lambda_vm_pc_uni(U = U, alpha = alpha)
lambda_pm
lambda_uni

data_pm <- list(
  N = length(xs),
  x = as.numeric(xs),
  lambda = lambda_pm
)

data_uni <- list(
  N = length(xs),
  x = as.numeric(xs),
  lambda = lambda_uni
)

data_exp <- list(
  N = length(xs),
  x = as.numeric(xs),
  lambda = 5
)

data_h <- list(
  N = length(xs),
  x = as.numeric(xs)
)

set.seed(520)
fit_pm <- stan(
  file = stan_model_pc_pm,
  data = data_pm,
  iter = 5000,
  warmup = 1500,
  chains = 4,
  init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
)

set.seed(520)
fit_uni <- stan(
  file = stan_model_pc_uni,
  data = data_uni,
  iter = 5000,
  warmup = 1500,
  chains = 4,
  init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
)

set.seed(520)
fit_exp <- stan(
  file = stan_model_exp,
  data = data_exp,
  iter = 5000,
  warmup = 1500,
  chains = 4,
  init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
)

set.seed(520)
fit_h2 <- stan(
  file = stan_model_h2,
  data = data_h,
  iter = 5000,
  warmup = 1500,
  chains = 4,
  init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
)

set.seed(520)
fit_h3 <- stan(
  file = stan_model_h3,
  data = data_h,
  iter = 5000,
  warmup = 1500,
  chains = 4,
  init = replicate(4, init_fn_vonmises_stan(), simplify = FALSE)
)

fit_pm_summary <- summary(fit_pm)$summary
fit_uni_summary <- summary(fit_uni)$summary
fit_exp_summary <- summary(fit_exp)$summary
fit_h2_summary <- summary(fit_h2)$summary
fit_h3_summary <- summary(fit_h3)$summary

fit_pm_summary
fit_uni_summary
fit_exp_summary
fit_h2_summary
fit_h3_summary

mu_mean_pm <- as.numeric(fit_pm_summary[1,1])
mu_mean_uni <- as.numeric(fit_uni_summary[1,1])
mu_mean_exp <- as.numeric(fit_exp_summary[1,1])
mu_mean_h2 <- as.numeric(fit_h2_summary[1,1])
mu_mean_h3 <- as.numeric(fit_h3_summary[1,1])

mean(as.circular(xs))
mu_mean_pm
mu_mean_uni
mu_mean_exp
mu_mean_h2
mu_mean_h3

kappa_mean_pm <- as.numeric(fit_pm_summary[2,1])
kappa_mean_uni <- as.numeric(fit_uni_summary[2,1])
kappa_mean_exp <- as.numeric(fit_exp_summary[2,1])
kappa_mean_h2 <- as.numeric(fit_h2_summary[2,1])
kappa_mean_h3 <- as.numeric(fit_h3_summary[2,1])

var.circular(xs)
1 - besselI(kappa_mean_pm, 1)/besselI(kappa_mean_pm, 0)
1 - besselI(kappa_mean_uni, 1)/besselI(kappa_mean_uni, 0)
1 - besselI(kappa_mean_exp, 1)/besselI(kappa_mean_exp, 0)
1 - besselI(kappa_mean_h2, 1)/besselI(kappa_mean_h2, 0)
1 - besselI(kappa_mean_h3, 1)/besselI(kappa_mean_h3, 0)






