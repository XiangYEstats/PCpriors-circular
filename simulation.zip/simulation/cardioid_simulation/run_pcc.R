N = as.double(commandArgs(trailingOnly = TRUE)[1])
ell = as.double(commandArgs(trailingOnly = TRUE)[2])
alpha = as.double(commandArgs(trailingOnly = TRUE)[3])

library(rstan)
library(circular)

stan_model <- "models/cardioid_pc_card_stan.stan"
source("functions/get_lambda_card_pc_cardioid.R")
source("functions/init_fn_cardioid_stan.R")
source("functions/simulate_fit_averaging_card_pc.R")
source("setting/conformable_setting.R")

lambda <- get_lambda_card_pc_card(U = U_ell, alpha = alpha)

res <- simulate_fit_cardioid_pc(m = m, N = N, mu_true = mu_true,
                                  ell_true = ell,
                                  lambda = lambda,
                                stan_model = stan_model,
                                  init_fn = init_fn_cardioid_stan,
                                  random_seed = 520)

print(res)

# Ensure the output folder exists
output_folder <- "results_pc_card/"
if (!dir.exists(output_folder)) {
  dir.create(output_folder)
}

# Combine the values into a data frame correctly (for averaged results)
results_df <- data.frame(
  lower_95 = res$lower_95,
  upper_95 = res$upper_95,
  mean = res$posterior_mean,
  median = res$posterior_median,
  se_mean = res$se_mean,
  sd = res$sd
)

# Use the formatted kappa in the file names
fnm_combined <- paste0(output_folder, "pcc-", N, "-", ell, "-", alpha, ".csv")
write.csv(results_df, file = fnm_combined, row.names = FALSE)

fnm_done <- paste0(output_folder, "done-pcc-", N, "-", ell, "-", alpha)
cat("done-pcc", file = fnm_done)

