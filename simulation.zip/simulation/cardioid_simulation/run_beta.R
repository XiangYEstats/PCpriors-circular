N = as.double(commandArgs(trailingOnly = TRUE)[1])
ell = as.double(commandArgs(trailingOnly = TRUE)[2])
a_ell = as.double(commandArgs(trailingOnly = TRUE)[3])
b_ell = as.double(commandArgs(trailingOnly = TRUE)[4])


library(rstan)
library(circular)

stan_model <- "models/cardioid_beta_stan.stan"
source("functions/init_fn_cardioid_stan.R")
source("functions/simulate_fit_averaging_card_beta.R")
source("setting/conformable_setting.R")

res <- simulate_fit_cardioid_beta(m = m, N = N, mu_true = mu_true,
                                  ell_true = ell,
				  a_ell = a_ell, b_ell = b_ell,
                                  stan_model = stan_model,
                                  init_fn = init_fn_cardioid_stan,
                                  random_seed = 520)

print(res)

# Ensure the output folder exists
output_folder <- "results_beta/"
if (!dir.exists(output_folder)) {
  dir.create(output_folder)
}

# Combine the values into a data frame correctly (for averaged results)
results_df <- data.frame(
  lower_95 = res$lower_95,
  upper_95 = res$upper_95,
  mean = res$posterior_mean,
  median = res$posterior_median,
  se_mean = res$se_mean,
  sd = res$sd
)



# Use the formatted kappa in the file names
fnm_combined <- paste0(output_folder, "beta-", N, "-", ell, "-", a_ell, "-", b_ell, ".csv")
write.csv(results_df, file = fnm_combined, row.names = FALSE)

fnm_done <- paste0(output_folder, "done-beta-", N, "-", ell, "-", a_ell, "-", b_ell)
cat("done-beta-", file = fnm_done)
