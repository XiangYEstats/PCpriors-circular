#!/bin/bash -l
#SBATCH -p batch
#SBATCH -J "simulation_jobs_N100"
#SBATCH --time=12:00:00
#SBATCH -o Err_Out/%A_%a.out
#SBATCH -e Err_Out/%A_%a.err
#SBATCH --nodes=8
#SBATCH --ntasks-per-node=1
#SBATCH --mem=150GB
#SBATCH --array=1-7

# Load required modules (if needed)
source ~/lmodules.sh

# Ensure output directory exists
mkdir -p Err_Out
mkdir -p $R_LIBS

# Define fixed N value and varying arclength and alpha values
N=100
ell_values=(0 0.01 0.1 0.2 0.3 0.4 0.49)


# Compute indices for arclength and alpha based on SLURM_ARRAY_TASK_ID
index=$((SLURM_ARRAY_TASK_ID-1))
ell=${ell_values[$index]}

# Run the R script with the current combination of N, arclength, alpha
Rscript run_uni.R $N $ell > UNI-$N-$ell.out 2>&1

