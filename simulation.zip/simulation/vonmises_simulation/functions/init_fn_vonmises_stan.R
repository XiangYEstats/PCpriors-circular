init_fn_vonmises_stan <- function() {
  list(
    mu = runif(1, 0, 2 * pi),
    kappa = runif(1, 1, 2)
  )
}
