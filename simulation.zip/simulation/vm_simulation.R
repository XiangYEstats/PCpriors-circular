library(ggplot2)
library(gridExtra)
library(dplyr)
library(cowplot)
library(viridis)

# Define the format_name function to extract parameters from filenames
format_name <- function(filename) {
  # Adjust regex based on filename patterns observed
  if (grepl("pcu-|pcp-", filename)) {
    # For PC prior files (uniform and point mass)
    match <- regmatches(filename, regexec("pc[up]-(\\d+)-(\\d+\\.\\d+)-(\\d+\\.\\d+)\\.csv", filename))[[1]]
    new_name <- paste0("N", match[2], "_kappa", match[3], "_alpha", match[4])
  } else if (grepl("exp-", filename)) {
    # For exp prior files
    match <- regmatches(filename, regexec("exp-(\\d+)-(\\d+\\.\\d+|\\.\\d+)-(\\d+\\.\\d+|\\d+|\\.\\d+)\\.csv", filename))[[1]]
    new_name <- paste0("N", match[2], "_kappa", match[3], "_lambda", match[4])
  } else if (grepl("h2-|h3-", filename)) {
    # For h2 and h3 files
    match <- regmatches(filename, regexec("h[23]-(\\d+)-(\\d+\\.\\d+)\\.csv", filename))[[1]]
    new_name <- paste0("N", match[2], "_kappa", match[3])
  } else {
    new_name <- filename
  }
  return(new_name)
}

# Load PCU prior results
pcu_files <- list.files(path = "vonmises_simulation/results_pc_uniform", pattern = "^pcu-.*\\.csv$", full.names = TRUE)
pcu_data <- lapply(pcu_files, read.csv)
names(pcu_data) <- sapply(pcu_files, format_name)

# Load PCP prior results
pcp_files <- list.files(path = "vonmises_simulation/results_pc_pointmass", pattern = "^pcp-.*\\.csv$", full.names = TRUE)
pcp_data <- lapply(pcp_files, read.csv)
names(pcp_data) <- sapply(pcp_files, format_name)

# Load exp prior results
exp_files <- list.files(path = "vonmises_simulation/results_exp", pattern = "^exp-.*\\.csv$", full.names = TRUE)
exp_data <- lapply(exp_files, read.csv)
names(exp_data) <- sapply(exp_files, format_name)

# Load h2 and h3 results
h2_files <- list.files(path = "vonmises_simulation/results_h2", pattern = "^h2-.*\\.csv$", full.names = TRUE)
h2_data <- lapply(h2_files, read.csv)
names(h2_data) <- sapply(h2_files, format_name)

h3_files <- list.files(path = "vonmises_simulation/results_h3", pattern = "^h3-.*\\.csv$", full.names = TRUE)
h3_data <- lapply(h3_files, read.csv)
names(h3_data) <- sapply(h3_files, format_name)

# Combine h2 and h3 data into a single group with proper labels
h2_data_combined <- bind_rows(h2_data, .id = "id") %>%
  mutate(
    prior_type = "MML",   # New unified prior type
    prior_setting = "h2", # Label as "h2"
    N = as.numeric(sub("N(\\d+)_.*", "\\1", id)),
    kappa = as.numeric(sub(".*_kappa([0-9.]+).*", "\\1", id))
  ) %>%
  select(id, N, kappa, prior_type, prior_setting, mean, lower_95, upper_95) # Keep only necessary columns

h3_data_combined <- bind_rows(h3_data, .id = "id") %>%
  mutate(
    prior_type = "MML",   # Same prior type as "h2"
    prior_setting = "h3", # Label as "h3"
    N = as.numeric(sub("N(\\d+)_.*", "\\1", id)),
    kappa = as.numeric(sub(".*_kappa([0-9.]+).*", "\\1", id))
  ) %>%
  select(id, N, kappa, prior_type, prior_setting, mean, lower_95, upper_95) # Keep only necessary columns

# Combine h2 and h3 into one dataset
mml_data <- bind_rows(h2_data_combined, h3_data_combined)

# Combine all datasets into one dataframe
combined_df <- bind_rows(
  bind_rows(pcu_data, .id = "id") %>% 
    mutate(prior_type = "PCU",  # PC Uniform
           prior_setting = paste0("PCU(", sub(".*_alpha([0-9.]+).*", "\\1", id), ")")),
  bind_rows(pcp_data, .id = "id") %>% 
    mutate(prior_type = "PCP",  # PC Point Mass
           prior_setting = paste0("PCP(", sub(".*_alpha([0-9.]+).*", "\\1", id), ")")),
  bind_rows(exp_data, .id = "id") %>% 
    mutate(prior_type = "Exp", 
           prior_setting = paste0("Exp(", sub(".*_lambda([0-9.]+).*", "\\1", id), ")")),
  mml_data  # Include the combined MML data
)

# Extract relevant parameters from the filenames and clean the data
combined_df <- combined_df %>%
  mutate(
    N = as.numeric(sub("N(\\d+)_.*", "\\1", id)),
    kappa = as.numeric(sub(".*_kappa([0-9.]+).*", "\\1", id)),
    prior_setting_value = ifelse(prior_type == "MML", NA,  # Update h2_h3 to MML
                                 as.numeric(sub(".*_(alpha|lambda)([0-9.]+).*", "\\2", id))),
    prior_setting = ifelse(prior_type == "MML", prior_setting,  # Keep "h2" or "h3" for MML
                           paste0(prior_type, "(", prior_setting_value, ")"))
  ) %>%
  filter(!is.na(kappa), N %in% c(100, 300, 1000)) # Filter out invalid kappa and N=1, N=2

# Summarise data, assuming 'mean', 'lower_95', and 'upper_95' exist
combined_df <- combined_df %>%
  group_by(N, kappa, prior_type, prior_setting) %>%
  summarise(
    mean = mean(mean, na.rm = TRUE),             # Use 'mean' column directly
    lower_95 = mean(lower_95, na.rm = TRUE),     # Average lower_95
    upper_95 = mean(upper_95, na.rm = TRUE),     # Average upper_95
    .groups = "drop"
  )

# Update prior_type names for clarity
combined_df <- combined_df %>%
  mutate(prior_type = case_when(
    prior_type == "PC (Uniform)" ~ "PCU",  # Rename PC Uniform
    prior_type == "PC (Point Mass)" ~ "PCP",  # Rename PC Point Mass
    prior_type == "MML" ~ "MML",  # Keep MML as is
    TRUE ~ prior_type  # Keep other types unchanged
  ))

# Generate separate color palettes for PCU, PCP, Exp, and MML groups
pcu_levels <- unique(combined_df$prior_setting[combined_df$prior_type == "PCU"])
pcp_levels <- unique(combined_df$prior_setting[combined_df$prior_type == "PCP"])
exp_levels <- unique(combined_df$prior_setting[combined_df$prior_type == "Exp"])
mml_levels <- unique(combined_df$prior_setting[combined_df$prior_type == "MML"])

# Generate distinct color palettes for each group
pcu_colors <- viridis::viridis(length(pcu_levels), option = "viridis")
pcp_colors <- viridis::viridis(length(pcp_levels), option = "viridis")
exp_colors <- viridis::viridis(length(exp_levels), option = "viridis")
mml_colors <- viridis::viridis(length(mml_levels), option = "viridis")

# Combine the color palettes into a single named vector
color_values <- c(
  setNames(pcu_colors, pcu_levels),
  setNames(pcp_colors, pcp_levels),
  setNames(exp_colors, exp_levels),
  setNames(mml_colors, mml_levels)
)

plot <- ggplot(combined_df, aes(x = prior_type, y = mean, color = prior_setting, group = prior_setting)) +
  geom_point(position = position_dodge(width = 0.8)) +
  geom_errorbar(
    aes(ymin = lower_95, ymax = upper_95), 
    width = 0.8, 
    position = position_dodge(width = 0.8), 
    size = 1.5
  ) +
  facet_grid(
    kappa ~ N, 
    scales = "free_y", 
    labeller = labeller(N = function(x) paste0("N=", x))
  ) +
  labs(
    x = "Prior Class", 
    y = expression(kappa~"(concentration parameter)"), 
    color = "Priors"
  ) +
  theme_grey(base_size = 14) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_line(color = "grey90"),
    panel.grid.minor = element_line(color = "grey90"),
    legend.position = "top",
    legend.text = element_text(size = 28),
    legend.title = element_text(size = 30, face = "bold"),
    axis.title.x = element_text(size = 32, face = "bold"),    # Larger x label
    axis.title.y = element_text(size = 32, face = "bold"),    # Larger y label
    axis.text.x  = element_text(size = 30),                   # Larger x-axis tick labels
    axis.text.y  = element_text(size = 30),                   # Larger y-axis tick labels
    strip.text.x = element_text(size = 30, face = "bold"),    # Larger facet text
    strip.text.y = element_text(size = 30, face = "bold")     # Larger facet text
  ) +
  scale_color_manual(values = color_values) +
  guides(color = guide_legend(title = "Priors", nrow = 2)) +
  geom_hline(
    data = combined_df %>% distinct(kappa),
    aes(yintercept = kappa),
    color = "black",
    linetype = 2,
    linewidth = 1.5
  )

print(plot)










ggsave("vm_simulation.png", plot = plot, width = 75, height = 73, units = "cm", dpi = 300, bg = "white")
