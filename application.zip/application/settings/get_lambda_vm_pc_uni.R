get_lambda_vm_pc_uni <- function(U, alpha) {
  kappa <- (2 * pi / U) - 1
  I1 <- besselI(kappa, 1)
  I0 <- besselI(kappa, 0)
  
  numerator <- log(1-alpha)
  denominator <- sqrt(kappa*I1/I0 - log(I0))
  
  return(-numerator/denominator)
}
