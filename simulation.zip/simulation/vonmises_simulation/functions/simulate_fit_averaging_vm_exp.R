simulate_fit_vonmises_exp <- function(m, N, mu_true, kappa_true, lambda, stan_model, init_fn, random_seed = 520) {
  
  # Initialize vectors to store credible intervals, means, and medians for kappa
  lower_95 <- numeric(m)
  upper_95 <- numeric(m)
  posterior_mean <- numeric(m)
  posterior_median <- numeric(m)
  se_mean <- numeric(m)
  sd <- numeric(m)
  
  # Loop through m iterations
  for (i in 1:m) {
    # Generate wrapped Cauchy data for this simulation
    set.seed(random_seed + i)
    xs <- suppressWarnings(rvonmises(n = N, mu = mu_true, kappa = kappa_true))
    
    # Prepare data for Stan model
    data_list <- list(
      N = length(xs),
      x = as.numeric(xs),
      lambda = lambda  # Pass the computed lambda
    )
    
    # Fit the Stan model
    set.seed(random_seed + i)
    fit <- stan(
      file = stan_model, 
      data = data_list, 
      iter = 2000,  # Number of iterations for MCMC
      warmup = 500,
      chains = 4,  # Number of chains
      init = replicate(4, init_fn(), simplify = FALSE),
      refresh = 0  # Suppress iteration info
    )
    
    # Get the summary for the fit
    fit_summary <- summary(fit)$summary
    
    # Extract posterior statistics for kappa
    lower_95[i] <- fit_summary["kappa", "2.5%"]
    upper_95[i] <- fit_summary["kappa", "97.5%"]
    posterior_mean[i] <- fit_summary["kappa", "mean"]
    posterior_median[i] <- fit_summary["kappa", "50%"]
    se_mean[i] <- fit_summary["kappa", "se_mean"]
    sd[i] <- fit_summary["kappa", "sd"]
  }
  
  # Compute the average of the posterior statistics across all simulations
  averaged_results <- list(
    lower_95 = mean(lower_95),
    upper_95 = mean(upper_95),
    posterior_mean = mean(posterior_mean),
    posterior_median = mean(posterior_median),
    se_mean = mean(se_mean),
    sd = mean(sd)
  )
  
  # Return the averaged results
  return(averaged_results)
}
